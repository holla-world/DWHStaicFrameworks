//
//  DWHStaticFramework.h
//  DWHStaticFramework
//
//  Created by admin on 26-12-21.
//

#import <Foundation/Foundation.h>

//! Project version number for DWHStaticFramework.
FOUNDATION_EXPORT double DWHStaticFrameworkVersionNumber;

//! Project version string for DWHStaticFramework.
FOUNDATION_EXPORT const unsigned char DWHStaticFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DWHStaticFramework/PublicHeader.h>


